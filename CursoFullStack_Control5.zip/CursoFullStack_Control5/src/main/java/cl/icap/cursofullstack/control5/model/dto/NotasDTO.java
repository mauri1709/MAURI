package cl.icap.cursofullstack.control5.model.dto;

public class NotasDTO {
	private Integer Curso ;
	private String Alumno ;
	private Integer Numero_modulo;
	private Integer Numero_evaluacion;
	private Integer Nota ;
	public NotasDTO() {
		super();
	}
	public NotasDTO(Integer curso, String alumno, Integer numero_modulo, Integer numero_evaluacion, Integer nota) {
		super();
		Curso = curso;
		Alumno = alumno;
		Numero_modulo = numero_modulo;
		Numero_evaluacion = numero_evaluacion;
		Nota = nota;
	}
	public Integer getCurso() {
		return Curso;
	}
	public void setCurso(Integer curso) {
		Curso = curso;
	}
	public String getAlumno() {
		return Alumno;
	}
	public void setAlumno(String alumno) {
		Alumno = alumno;
	}
	public Integer getNumero_modulo() {
		return Numero_modulo;
	}
	public void setNumero_modulo(Integer numero_modulo) {
		Numero_modulo = numero_modulo;
	}
	public Integer getNumero_evaluacion() {
		return Numero_evaluacion;
	}
	public void setNumero_evalucaion(Integer numero_evaluacion) {
		Numero_evaluacion = numero_evaluacion;
	}
	public Integer getNota() {
		return Nota;
	}
	public void setNota(Integer nota) {
		Nota = nota;
	}
	
	
	
	
}
