package cl.icap.cursofullstack.control5.model.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import cl.icap.cursofullstack.control5.model.dto.NotasDTO;

@Repository
@Transactional
public class NotasDAOImpl implements NotasDAO{
	
	private String list = "SELECT * FROM notas ORDER BY nota";
	private String select = "SELECT * FROM notas WHERE notas=?";
	private String insert = "INSERT INTO notas VALUES (?,?,?,?,?)";
	private String update = "UPDATE notas SET curso=?, alumno=?, Numero_modulo=?, Numero_evaluacion=?, nota=? WHERE nota=?";
	private String delete = "DELETE notas  WHERE nota=?";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public List<NotasDTO> list() {
		List<NotasDTO> listNotasDTO = jdbcTemplate.query(list,
				BeanPropertyRowMapper.newInstance(NotasDTO.class));
		return listNotasDTO;
	}
	@Override
	public NotasDTO get(Integer nota) {
	    Object[] args = {nota};
	    NotasDTO NotasDTO;
	    
	    try {
	    	NotasDTO = jdbcTemplate.queryForObject(select,args,
	    		BeanPropertyRowMapper.newInstance(NotasDTO.class));
	    } catch (EmptyResultDataAccessException e) {
	    	NotasDTO=null;
	    	e.printStackTrace();
	    } catch (Exception e) {
	    	NotasDTO=null;
	    	e.printStackTrace();
	    }
	    return NotasDTO;
	}
	@Override
	public int insert(NotasDTO notasDTO) {
		int rows = 0;
	    Object[] args = {
	    		notasDTO.getCurso(),
	    		notasDTO.getAlumno(),
	    		notasDTO.getNumero_modulo(),
	    		notasDTO.getNumero_evaluacion(),
	    		notasDTO.getNota(),

	    		};
	    try {
			rows = jdbcTemplate.update(insert, args);	
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
	    return rows;
	}
	@Override
	public int update(NotasDTO notasDTO) {
		int rows = 0;
	    Object[] args = {
	    		notasDTO.getCurso(),
	    		notasDTO.getAlumno(),
	    		notasDTO.getNumero_modulo(),
	    		notasDTO.getNumero_evaluacion(),
	    		notasDTO.getNota(),

	    		};
	    try {
			rows = jdbcTemplate.update(update, args);	
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
	    return rows;
	}
	@Override
	public int delete(Integer nota ) {
		int rows = 0;
	    Object[] args = {nota};
	    try {
			rows = jdbcTemplate.update(delete, args);	
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
	    return rows;
	}
}
