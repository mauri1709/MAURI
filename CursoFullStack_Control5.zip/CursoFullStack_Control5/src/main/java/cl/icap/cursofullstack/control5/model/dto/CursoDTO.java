package cl.icap.cursofullstack.control5.model.dto;

public class CursoDTO {
private Integer Codigo;
private String Nombre_curso;
public CursoDTO() {
	super();
}
public CursoDTO(Integer codigo, String nombre_curso) {
	super();
	Codigo = codigo;
	Nombre_curso = nombre_curso;
}
public Integer getCodigo() {
	return Codigo;
}
public void setCodigo(Integer codigo) {
	Codigo = codigo;
}
public String getNombre_curso() {
	return Nombre_curso;
}
public void setNombre_curso(String nombre_curso) {
	Nombre_curso = nombre_curso;
}


	
	
}
