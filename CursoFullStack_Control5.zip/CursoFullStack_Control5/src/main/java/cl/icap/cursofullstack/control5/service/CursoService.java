package cl.icap.cursofullstack.control5.service;

import java.util.List;

import cl.icap.cursofullstack.control5.model.dto.CursoDTO;

public interface CursoService {

	public List<CursoDTO> list();
	public CursoDTO get(Integer Codigo);
	public int insert(CursoDTO CursoDTO);
	public int update(CursoDTO CursoDTO);
	public int delete(Integer Codigo);
}
