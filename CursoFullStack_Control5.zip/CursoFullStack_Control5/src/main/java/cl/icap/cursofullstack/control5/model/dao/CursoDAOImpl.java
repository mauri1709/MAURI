package cl.icap.cursofullstack.control5.model.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import cl.icap.cursofullstack.control5.model.dto.CursoDTO;

@Repository
@Transactional
public class CursoDAOImpl implements CursoDAO{
	
	private String list = "SELECT * FROM curso ORDER BY codigo";
	private String select = "SELECT * FROM curso WHERE codigo=?";
	private String insert = "INSERT INTO curso VALUES (?,?)";
	private String update = "UPDATE curso SET codigo=?, nombre_curso=? WHERE codigo=?";
	private String delete = "DELETE curso WHERE codigo=?";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public List<CursoDTO> list() {
		List<CursoDTO> listCursoDTO = jdbcTemplate.query(list,
				BeanPropertyRowMapper.newInstance(CursoDTO.class));
		return listCursoDTO;
	}
	@Override
	public CursoDTO get(Integer Codigo) {
	    Object[] args = {Codigo};
	    CursoDTO CursoDTO;
	    
	    try {
	    	CursoDTO = jdbcTemplate.queryForObject(select,args,
	    		BeanPropertyRowMapper.newInstance(CursoDTO.class));
	    } catch (EmptyResultDataAccessException e) {
	    	CursoDTO=null;
	    	e.printStackTrace();
	    } catch (Exception e) {
	    	CursoDTO=null;
	    	e.printStackTrace();
	    }
	    return CursoDTO;
	}
	@Override
	public int insert(CursoDTO CursoDTO) {
		int rows = 0;
	    Object[] args = {
	    		CursoDTO.getCodigo(),
	    		CursoDTO.getNombre_curso(),

	    		};
	    try {
			rows = jdbcTemplate.update(insert, args);	
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
	    return rows;
	}
	@Override
	public int update(CursoDTO CursoDTO) {
		int rows = 0;
	    Object[] args = {
	    		CursoDTO.getCodigo(),
	    		CursoDTO.getNombre_curso(),
	    		
	    		};
	    try {
			rows = jdbcTemplate.update(update, args);	
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
	    return rows;
	}
	@Override
	public int delete(Integer Codigo) {
		int rows = 0;
	    Object[] args = {Codigo};
	    try {
			rows = jdbcTemplate.update(delete, args);	
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
	    return rows;
	}

}
