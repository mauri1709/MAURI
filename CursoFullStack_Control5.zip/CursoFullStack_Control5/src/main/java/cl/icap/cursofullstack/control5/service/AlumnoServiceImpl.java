package cl.icap.cursofullstack.control5.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.icap.cursofullstack.control5.model.dao.AlumnoDAO;
import cl.icap.cursofullstack.control5.model.dto.AlumnoDTO;

@Service
public class AlumnoServiceImpl implements AlumnoService {

	//hacemos uso de la interfaz SalesDAO
	@Autowired
	AlumnoDAO alumnoDAO; 
	
	public AlumnoServiceImpl() {
		 
	}

	//implementamos método lista.Se implementa el método definido en la interfaz.
	public List<AlumnoDTO> list(){
		return alumnoDAO.list();
	}

	@Override
	public int insert(AlumnoDTO alumnoDTO) {
		return alumnoDAO.insert(alumnoDTO);
	}

	@Override
	public AlumnoDTO get(String Rut) {
	return alumnoDAO.get(Rut);
	
	}

	@Override
	public int update(AlumnoDTO alumnoDTO) {
	return alumnoDAO.update(alumnoDTO);
	}

	@Override
	public int delete(String Rut) {
		return alumnoDAO.delete(Rut);
	}
	
}
