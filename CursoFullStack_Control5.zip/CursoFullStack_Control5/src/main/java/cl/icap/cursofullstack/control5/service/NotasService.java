package cl.icap.cursofullstack.control5.service;

import java.util.List;

import cl.icap.cursofullstack.control5.model.dto.NotasDTO;

public interface NotasService {
	public List<NotasDTO> list();
	public NotasDTO get(Integer codigo);
	public int insert(NotasDTO notasDTO);
	public int update(NotasDTO notasDTO);
	public int delete(Integer codigo);

}
