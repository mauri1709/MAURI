package cl.icap.cursofullstack.control5.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Servlet implementation class WebAppController
 */
@Controller("/WebAppController")
public class WebAppController {
	
		@RequestMapping("/")
		public String getHome(){
			return "index";
		}
	
		@RequestMapping("/notas")
		public String getNotas(){
			return "notas";
		}
		
		@RequestMapping("/curso")
		public String getCurso() {
			return "curso";
			
		}
		
		@RequestMapping("/403")
		public String get403(){
			return "403";
		}

		@RequestMapping("/Alumnos")
		public String getAlumno(){
			return "Alumnos";
		}
		
		

}
