package cl.icap.cursofullstack.control5.model.dao;

import java.util.List;

import cl.icap.cursofullstack.control5.model.dto.AlumnoDTO;

public interface AlumnoDAO {


public int insert(AlumnoDTO alumnoDTO); //Es tipo int debido a que la operación devuelve la cantidad de filas modificadas, en este caso queremos realizar sólo una modificacion. Recibe un dato tipo SalesDTO con nombre SalesDTO
public AlumnoDTO get(String rut); //como es un read, vamos a obtener un dato de SalesDTO, un sólo sale y lo manejamos a nivel DTO,
public int update(AlumnoDTO alumnoDTO); //recibe un dato tipo SalesDTO con nombre SalesDTO
public int delete(String rut);//
public List<AlumnoDTO> list();// una lista de tipo SalesDTO llamado list
}
