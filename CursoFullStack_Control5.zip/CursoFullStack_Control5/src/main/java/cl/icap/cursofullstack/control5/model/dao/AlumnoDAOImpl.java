package cl.icap.cursofullstack.control5.model.dao;

import java.sql.PreparedStatement;
import java.sql.Types;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import cl.icap.cursofullstack.control5.model.dto.AlumnoDTO;

@Repository
public class AlumnoDAOImpl implements AlumnoDAO {
	private String insert="INSERT INTO alumno (Rut,Nombre, Curso) VALUES(:Rut, :Nombre, :Curso)";
	private String select="SELECT * FROM alumno WHERE Rut=?";
	private String update="UPDATE alumno SET Rut= :Rut, Nombre= :Nombre, Curso= :Curso WHERE Rut= :Rut";
	private String delete="DELETE FROM alumno WHERE Id_bl=?";
	private String list="SELECT * FROM alumno";
	

	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired 
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	

	@Override
	public int insert(AlumnoDTO alumnoDTO) {
		

	
		int rows =0;
	
		 
		try {
		
	
			MapSqlParameterSource params =new MapSqlParameterSource();
			
			params.addValue("Rut", alumnoDTO.getRut(), Types.VARCHAR);
			params.addValue("Nombre", alumnoDTO.getNombre(), Types.VARCHAR);
			params.addValue("Curso", alumnoDTO.getCurso(), Types.INTEGER);
			
			rows = namedParameterJdbcTemplate.update(insert, params);
			
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		return rows;
		
	}

	@Override
	public AlumnoDTO get(String Rut) {
		Object args[]= {Rut};
		AlumnoDTO alumnoDTO;
		try {
			alumnoDTO= jdbcTemplate.queryForObject(select, args, BeanPropertyRowMapper.newInstance(AlumnoDTO.class));
			
		} catch (Exception e) {
			alumnoDTO=null;
			e.printStackTrace();
		}
		return alumnoDTO; 
	}

	@Override
	public int update(AlumnoDTO AlumnoDTO) {
		int rows =0;
	
		MapSqlParameterSource params =new MapSqlParameterSource();
		
		params.addValue("Rut", AlumnoDTO.getRut(), Types.VARCHAR);
		params.addValue("Nombre", AlumnoDTO.getNombre(), Types.VARCHAR);
		params.addValue("Curso", AlumnoDTO.getCurso(), Types.INTEGER);
			try {
				
				rows = namedParameterJdbcTemplate.update(update, params);
				
					
			 } catch (Exception e) {
					e.printStackTrace();
				
				}
				 	
			return rows;
	}
	


	@Override
	public int delete(String Rut) {
	int rows=0;
	
		Object args[]= {Rut};
	try {
			rows= jdbcTemplate.update(delete,args);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rows; 
	}

	@Override
	public List<AlumnoDTO> list() {
	//devuelve un tipo List SalesDTO
	//vamos a hacer un mapeo para la fila. Se ocupa el rowMapper -->se ocupa clase BeanPropertyRowMapper, convierte una clase a un objeto, así
	//jdbcTemplate sabe que tiene que devolver un dato tipo SalesDTO
	//como esta consulta no recibe argumentos dado que es un Select * ; por lo tanto se quita el "args".	
		List<AlumnoDTO> listbl= jdbcTemplate.query(list, BeanPropertyRowMapper.newInstance(AlumnoDTO.class));
		return listbl;
	}

}
