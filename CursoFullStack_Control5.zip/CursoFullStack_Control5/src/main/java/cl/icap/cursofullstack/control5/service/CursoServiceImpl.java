package cl.icap.cursofullstack.control5.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.icap.cursofullstack.control5.model.dao.CursoDAO;
import cl.icap.cursofullstack.control5.model.dto.CursoDTO;

@Service
public class CursoServiceImpl implements CursoService{

	@Autowired
	CursoDAO cursoDAO;

	@Override
	public List<CursoDTO> list() {
		return cursoDAO.list();
	}

	@Override
	public CursoDTO get(Integer Codigo) {
		return cursoDAO.get(Codigo);
	}

	@Override
	public int insert(CursoDTO cursoDTO) {
		return cursoDAO.insert(cursoDTO);
	}

	@Override
	public int update(CursoDTO cursoDTO) {
		return cursoDAO.update(cursoDTO);
	}

	@Override
	public int delete(Integer Codigo) {
		return cursoDAO.delete(Codigo);
	}
	
}
