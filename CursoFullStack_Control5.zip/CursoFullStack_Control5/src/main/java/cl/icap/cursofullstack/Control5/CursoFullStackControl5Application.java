package cl.icap.cursofullstack.Control5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursoFullStackControl5Application {

	public static void main(String[] args) {
		SpringApplication.run(CursoFullStackControl5Application.class, args);
	}

}
