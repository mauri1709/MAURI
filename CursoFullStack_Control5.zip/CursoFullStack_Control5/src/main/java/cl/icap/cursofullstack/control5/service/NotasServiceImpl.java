package cl.icap.cursofullstack.control5.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.icap.cursofullstack.control5.model.dao.NotasDAO;
import cl.icap.cursofullstack.control5.model.dto.NotasDTO;

@Service
public class NotasServiceImpl implements NotasService{
	@Autowired
	NotasDAO NotasDAO;
	@Override
	public List<NotasDTO> list(){
		return NotasDAO.list();
	}
	@Override
	public NotasDTO get(Integer nota) {
		return NotasDAO.get(nota);
	}
	@Override
	public int delete(Integer nota) {
		return NotasDAO.delete(nota);	
	}
	@Override
	public int insert(NotasDTO NotasDTO) {
		return NotasDAO.insert(NotasDTO);
	}
	@Override
	public int update(NotasDTO NotasDTO) {
		return NotasDAO.update(NotasDTO);
	}
}
