package cl.icap.cursofullstack.control5.model.dto;



public class AlumnoDTO {
 // ocupamos la clase Integer, porque JDBC template cuando el dato es nulo y nativo de Java, se cae. 	
private Integer  Rut ;
private String Nombre;
private Integer Curso;
public AlumnoDTO() {
	super();
}
public AlumnoDTO(Integer rut, String nombre, Integer curso) {
	super();
	Rut = rut;
	Nombre = nombre;
	Curso = curso;
}
public Integer getRut() {
	return Rut;
}
public void setRut(Integer rut) {
	Rut = rut;
}
public String getNombre() {
	return Nombre;
}
public void setNombre(String nombre) {
	Nombre = nombre;
}
public Integer getCurso() {
	return Curso;
}
public void setCurso(Integer curso) {
	Curso = curso;
}





}

