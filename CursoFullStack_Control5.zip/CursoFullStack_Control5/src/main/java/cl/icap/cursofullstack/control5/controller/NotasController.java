package cl.icap.cursofullstack.control5.controller;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import cl.icap.cursofullstack.control5.model.dto.NotasDTO;
import cl.icap.cursofullstack.control5.service.NotasService;



@RestController
@RequestMapping(value="/notas")
public class NotasController {
	
	@Autowired
	NotasService NotasService;
	
	@RequestMapping(value="/list")
	public @ResponseBody List<NotasDTO> ajaxList(HttpServletRequest req, HttpServletResponse res) {
		List<NotasDTO> list = NotasService.list();
		return list;
	}
	
	@RequestMapping(value="/get")
	public @ResponseBody NotasDTO ajaxGet(HttpServletRequest req, HttpServletResponse res) {
		NotasDTO nota = NotasService.get(Integer.parseInt((req.getParameter("Nota"))));
		return nota;
	}
	
	@RequestMapping(value="/delete")
	public @ResponseBody int ajaxDelete(HttpServletRequest req, HttpServletResponse res) {
		int rows = NotasService.delete(Integer.parseInt(req.getParameter("Nota")));
		return rows;
	}
	
	@RequestMapping(value="/insert")
	public @ResponseBody int ajaxInsert(HttpServletRequest req, HttpServletResponse res) {
		int rows=0;
		try {
			String requestData = req.getReader().lines().collect(Collectors.joining());
			NotasDTO nota = new Gson().fromJson(requestData, NotasDTO.class);
			rows = NotasService.insert(nota);
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		return rows;
	}
	
	@RequestMapping(value="/update")
	public @ResponseBody int ajaxUpdate(HttpServletRequest req, HttpServletResponse res) {
		int rows=0;
		try {
			String requestData = req.getReader().lines().collect(Collectors.joining());
			NotasDTO nota = new Gson().fromJson(requestData, NotasDTO.class);
			rows = NotasService.update(nota);
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		return rows;
	}

}
