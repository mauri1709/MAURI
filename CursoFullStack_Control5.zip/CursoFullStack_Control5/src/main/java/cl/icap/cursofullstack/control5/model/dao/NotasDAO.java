package cl.icap.cursofullstack.control5.model.dao;
import java.util.List;

import cl.icap.cursofullstack.control5.model.dto.NotasDTO;
public interface NotasDAO {
	
	public List<NotasDTO> list();
	public NotasDTO get(Integer Nota);
	public int insert(NotasDTO NotasDTO);
	public int update(NotasDTO NotasDTO);
	public int delete(Integer Nota);

}
