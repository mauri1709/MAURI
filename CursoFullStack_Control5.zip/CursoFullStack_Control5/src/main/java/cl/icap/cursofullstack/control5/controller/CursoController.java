package cl.icap.cursofullstack.control5.controller;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cl.icap.cursofullstack.control5.model.dto.CursoDTO;
import cl.icap.cursofullstack.control5.service.CursoService;

@RestController
@RequestMapping(value="/curso") //todo lo que tenga sales --direcciona a esta clase.
public class CursoController {
	
	@Autowired
	CursoService cursoService;

	@RequestMapping(value="/list")
	public @ResponseBody List<CursoDTO> ajaxList(HttpServletRequest req,HttpServletResponse res){
		return cursoService.list();
	}
	
	@RequestMapping(value="/get")
	public @ResponseBody CursoDTO ajaxGet(HttpServletRequest req,HttpServletResponse res){
		return cursoService.get(Integer.parseInt(req.getParameter("Codigo")));
	}
	
	@RequestMapping(value="/insert")
	public @ResponseBody int ajaxInsert(HttpServletRequest req,HttpServletResponse res){
	
		int rows=0;
		String requestData;
		try {
			requestData = req.getReader().lines().collect(Collectors.joining());
			
			//cuando mandamos fecha desde web a controller, nos manda la fecha de cÃ³mo estÃ¡ en el cliente, por lo tanto lo dejamos como formato de java.sql
			
			
			Gson gson=new GsonBuilder().serializeNulls().create();
				
			//transforma la estructura de datos que viene del javascript para enviarla a DTO. viende de requestData y lo manda a SalesDTO.class
			CursoDTO curso =gson.fromJson(requestData, CursoDTO.class);
		
			rows= cursoService.insert(curso);
		} catch (IOException e) {
			e.printStackTrace();	
		}
		
		return rows;
		
		
	}
	
	@RequestMapping(value="/update")
	public @ResponseBody int ajaxUpdate(HttpServletRequest req,HttpServletResponse res){
		
		int rows=0;
		String requestData;
		try {
			requestData = req.getReader().lines().collect(Collectors.joining());
			Gson gson=new GsonBuilder().serializeNulls().create();
			CursoDTO curso =gson.fromJson(requestData, CursoDTO.class);
			rows= cursoService.update(curso);
		} catch (IOException e) {
			e.printStackTrace();	
		}
		
		return rows;
	}
	
	@RequestMapping(value="/delete")
	public @ResponseBody int ajaxDelete(HttpServletRequest req,HttpServletResponse res){
		int rows=0;
		try {
			rows= cursoService.delete(Integer.parseInt(req.getParameter("Codigo")));
			System.out.println(req.getParameter("Codigo"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rows;	
		}
}
