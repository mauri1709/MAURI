package cl.icap.cursofullstack.control5.service;

import java.util.List;

import cl.icap.cursofullstack.control5.model.dto.AlumnoDTO;

public interface AlumnoService {
		public int insert(AlumnoDTO AlumnoDTO); //Es tipo int debido a que la operación devuelve la cantidad de filas modificadas, en este caso queremos realizar sólo una modificacion. Recibe un dato tipo SalesDTO con nombre SalesDTO
		public AlumnoDTO get(String Rut); //como es un read, vamos a obtener un dato de SalesDTO, un sólo sale y lo manejamos a nivel DTO,
		public int update(AlumnoDTO AlumnoDTO); //recibe un dato tipo SalesDTO con nombre SalesDTO
		public int delete(String id);//
		public List<AlumnoDTO> list();
		
}

