function AlumnoController(option){
	$("#msg").hide();
	$("#msg").removeClass("alert-success").addClass("alert-danger");
	//var token = $("meta[name='_csrf']").attr("content");
	switch(option){
	
	case "list":
		$.ajax({
			type : "post",
			//headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/Alumno/list",
			success : function(res){
				$("#blTable").bootstrapTable('load',res);
				$("#blTable tbody").on('click','tr', function(){
					$("#rut").val($(this).find("td:eq(0)").text());
					$("#nombre").val($(this).find("td:eq(1)").text());
					$("#curso").val($(this).find("td:eq(2)").text());
		
					$("#blModal .close").click()
				});
				$("#blModal").modal({show:true})
			},
			error : function(){
				$("#msg").show();
				$("#msg").html("Error en la busqueda de Alumno");
			}
		});
		break;
		
	case "get":
		$.ajax({
			type : "post",
			//headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/Alumno/get",
			data: "rut=" + $("#rut").val(),
			success : function(res){
				if (res== null || res==""){
					$("#msg").show();
					$("#msg").html("Registro no encontrado")
				}else{
					$("#rut").val(res.rut);
					$("#nombre").val(res.nombre);
					$("#curso").val(res.curso);
					
					}
			},
			error : function(){
				$("#msg").show();
				$("#msg").html("Error en busqueda de Alumno");
			}
		});
		break;
	case "insert":
		var json = 
	{
			'rut' : $("#rut").val(),
			'nombre' : $("#nombre").val(),
			'curso' : $("#curso").val(),
			
			
	}
		var postData= JSON.stringify(json);
		
		$.ajax({
			type : "post",
			//headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/Alumno/insert",
			data: postData,
			contentType : "application/json; charset=utf-8",
			success : function(res){
				if (res== 1){
					$("#msg").removeClass("alert-danger").addClass("alert-success")
					$("#msg").show();
					$("#msg").html("Registro insertado correctamente")
				}else{
					$("#msg").show();
					$("#msg").html("Error al agregar registro")
				}
			},
			error : function(){
				$("#msg").show();
				$("#msg").html("Error al agregar registro");
			}
		});
		break;
		
	case "update":
		var json = 
	{
			'rut' : $("#curso").val(),
			'nombre' : $("#nombre").val(),
			'curso' : $("#curso").val(),
							
	}
	
		var postData= JSON.stringify(json);
		
		$.ajax({
			type : "post",
			//headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/Alumno/update",
			data: postData,
			contentType : "application/json; charset=utf-8",
			success : function(res){
				if (res== 1){
					$("#msg").removeClass("alert-danger").addClass("alert-success")
					$("#msg").show();
					$("#msg").html("Registro actualizado correctamente")
				}else{
					$("#msg").show();
					$("#msg").html("Error al actualizar registro")
				}
			},
			error : function(){
				$("#msg").show();
				$("#msg").html("Error al actualizar registro");
			}
		});
		break;
		
	case "delete":
		$.ajax({
			type : "post",
			//headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/Alumno/delete",
			data: "rut=" + $("#rut").val(),
			success : function(res){
				if (res==1){
					$("#msg").removeClass("alert-danger").addClass("alert-success")
					$("#msg").show();
					$("#msg").html("Registro eliminado con exito")
				}else{
					$("#msg").show();
					$("#msg").html("Registro no se pudo eliminar ")
				}
			},
			error : function(){
				$("#msg").show();
				$("#msg").html("Error al eliminar");
			}
		});
		break;
	default:
			$("#msg").show();
			$("#msg").html("Opcion no valida");
	}
}