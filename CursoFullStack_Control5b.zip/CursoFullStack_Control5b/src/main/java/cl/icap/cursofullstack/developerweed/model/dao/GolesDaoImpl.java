package cl.icap.cursofullstack.developerweed.model.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import cl.icap.cursofullstack.developerweed.model.dto.GOLESDTO;

@Repository
@Transactional
public class GolesDaoImpl implements GolesDAO {
	private String list = "SELECT * FROM jobs";
	private String get = "SELECT c.curso_cod, c.curso_nom, a.alumno_rut, a.alumno_nombre, n.nmodulo, n.neval, n.nota " +
			"FROM notas n, alumno a, curso c " +
			" WHERE n.alumno_rut=? and c.curso_cod=n.curso_cod and a.alumno_rut=n.alumno_rut ORDER BY n.nmodulo";
	private String insert = "INSERT INTO jobs VALUES (?,?,?,?)";
	private String update = "UPDATE Goles SET Rut=? Cantidad=? WHERE Rut=?";
	private String delete = "DELETE jobs WHERE job_id=?";

	@Autowired
	private JdbcTemplate jdbcTemplate;	

	@Override
	public List<GOLESDTO> list() {
			List<GOLESDTO> listJobs = jdbcTemplate.query(list,
					BeanPropertyRowMapper.newInstance(GOLESDTO.class));
			return listJobs;
		
	}

	@Override
	public List<GOLESDTO> get(int Jugador_Rut) {
		    Object[] args = {Jugador_Rut};
		    List<GOLESDTO> notasDTO;
		    
		    try {
		    	notasDTO = jdbcTemplate.query(get,args,BeanPropertyRowMapper.newInstance(GOLESDTO.class));
		    } catch (EmptyResultDataAccessException e) {
		    	notasDTO=null;
		    	e.printStackTrace();
		    } catch (Exception e) {
		    	notasDTO=null;
		    	e.printStackTrace();
		    }
		    return notasDTO;
		
	}

	@Override
	public int insert(GOLESDTO golesDTO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(GOLESDTO golesDTO) {
			int rows = 0;
		    Object[] args = {
		    		golesDTO.getJugador_Rut(),
		    		golesDTO.getCantidad_Goles(),
		    		};
		    try {
				rows = jdbcTemplate.update(update, args);	
		    } catch (Exception e) {
		    	e.printStackTrace();
		    }
		    return rows;
		
	}

	@Override
	public int delete(int Jugador_Rut) {
		// TODO Auto-generated method stub
		return 0;
	}

}
