package cl.icap.cursofullstack.developerweed.model.dto;

public class GOLESDTO {
	private int Jugador_Rut;
	private String Jugadr_Nom;
	private String Equipo;
	private int Equipo_Cod;
	private String Nombre_Equipo;
	private int Cantidad_Goles;
	
	public int getJugador_Rut() {
		return Jugador_Rut;
	}
	public void setJugador_Rut(int jugador_Rut) {
		Jugador_Rut = jugador_Rut;
	}
	public String getJugadr_Nom() {
		return Jugadr_Nom;
	}
	public void setJugadr_Nom(String jugadr_Nom) {
		Jugadr_Nom = jugadr_Nom;
	}
	public String getEquipo() {
		return Equipo;
	}
	public void setEquipo(String equipo) {
		Equipo = equipo;
	}
	public int getEquipo_Cod() {
		return Equipo_Cod;
	}
	public void setEquipo_Cod(int equipo_Cod) {
		Equipo_Cod = equipo_Cod;
	}
	public String getNombre_Equipo() {
		return Nombre_Equipo;
	}
	public void setNombre_Equipo(String nombre_Equipo) {
		Nombre_Equipo = nombre_Equipo;
	}
	public int getCantidad_Goles() {
		return Cantidad_Goles;
	}
	public void setCantidad_Goles(int cantidad_Goles) {
		Cantidad_Goles = cantidad_Goles;
	}


}
