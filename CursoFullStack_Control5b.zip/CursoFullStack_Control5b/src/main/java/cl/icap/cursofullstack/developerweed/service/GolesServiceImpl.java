package cl.icap.cursofullstack.developerweed.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.icap.cursofullstack.developerweed.model.dao.GolesDAO;
import cl.icap.cursofullstack.developerweed.model.dto.GOLESDTO;

@Service
public class GolesServiceImpl implements GolesDAO {
	
	@Autowired
	GolesDAO golesDAO;

	@Override
	public List<GOLESDTO> list() {
		return golesDAO.list();
	}

	@Override
	public List<GOLESDTO> get(int Jugador_Rut) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(GOLESDTO golesDTO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(GOLESDTO golesDTO) {
		
		return golesDAO.update(golesDTO);
	}

	@Override
	public int delete(int Jugador_Rut) {
		// TODO Auto-generated method stub
		return 0;
	}

}
