package cl.icap.cursofullstack.developerweed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursoFullStackControl5bApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursoFullStackControl5bApplication.class, args);
	}

}
