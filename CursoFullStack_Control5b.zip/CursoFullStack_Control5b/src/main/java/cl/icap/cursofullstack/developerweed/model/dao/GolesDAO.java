package cl.icap.cursofullstack.developerweed.model.dao;

import java.util.List;

import cl.icap.cursofullstack.developerweed.model.dto.GOLESDTO;

public interface GolesDAO {
	public List<GOLESDTO> list();
	public List<GOLESDTO> get(int Jugador_Rut);
	public int insert(GOLESDTO golesDTO);
	public int update(GOLESDTO golesDTO);
	public int delete(int Jugador_Rut);
}
