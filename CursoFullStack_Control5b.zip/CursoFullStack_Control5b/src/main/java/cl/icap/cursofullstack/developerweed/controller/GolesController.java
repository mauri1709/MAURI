package cl.icap.cursofullstack.developerweed.controller;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import cl.icap.cursofullstack.developerweed.model.dto.GOLESDTO;
import cl.icap.cursofullstack.developerweed.service.GolesService;


@RestController
@RequestMapping(value="/goles")
public class GolesController {
	@Autowired
	GolesService golesService;
	
	
	@RequestMapping(value="/get")
	public List<GOLESDTO> ajaxGet(HttpServletRequest req, HttpServletResponse res) {
		List<GOLESDTO> notas = golesService.get(Integer.parseInt(req.getParameter("jugador_rut")));
		return notas;
	}
	
	@RequestMapping(value="/update")
	public @ResponseBody int ajaxUpdate(HttpServletRequest req, HttpServletResponse res) {
		int rows=0;
		try {
			String requestData = req.getReader().lines().collect(Collectors.joining());
			GOLESDTO job = new Gson().fromJson(requestData, GOLESDTO.class);
			rows = golesService.update(job);
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		return rows;
	}
}
